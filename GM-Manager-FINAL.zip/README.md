# GM Manager — final project

This package is the GM Manager mobile web app plus the secure Vercel API routes.

## Files

- `index.html` — complete mobile GM Manager interface
- `api/analyze.js` — AI photo analysis/caption/recommendation route
- `api/edit.js` — real AI image-editing/pose route

## Deployment

Use the existing GitHub repository `gm-manager`.

Replace the existing `index.html` with the included `index.html` and add the `api` folder exactly as supplied.

In Vercel, create one environment variable:

`GEMINI_API_KEY`

The key must be stored in Vercel, NOT in `index.html`.

The analysis route uses Gemini 3.1 Flash-Lite. The pose-edit route uses Gemini 3.1 Flash Image.

Important: the image-generation API is not currently on Gemini's free API tier. The app itself and the analysis model can be used within applicable free-tier limits, but actual generative pose editing requires an image-generation API tier that supports the image model.

GM never automatically publishes to Instagram.
