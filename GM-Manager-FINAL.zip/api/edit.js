export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({error:"Method not allowed"});
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(500).json({error:"GEMINI_API_KEY is not configured in Vercel."});

  try {
    const {image, prompt} = req.body || {};
    const m = String(image || "").match(/^data:(image\/[^;]+);base64,(.+)$/);
    if (!m) return res.status(400).json({error:"A valid image is required."});
    if (m[2].length > 14_000_000) return res.status(413).json({error:"Image is too large. Use a smaller photo."});

    const instruction = `${prompt || "Make the pose more natural and relaxed."}

STRICT GM PHOTO RULES:
- Preserve the exact person's identity and recognizable facial features.
- Do not alter face structure.
- Do not slim, enlarge, reshape, or change body proportions.
- Do not change body size or shape.
- Preserve clothing, hairstyle, skin texture and realistic appearance.
- Keep the original environment/background as much as possible.
- Only make the requested pose change.
- The result must look like a genuine camera photograph, not an AI-looking portrait.
- Do not add or remove unrelated people or objects.
- Keep lighting and colors natural.
Return the edited image.`;

    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-image:generateContent", {
      method:"POST",
      headers:{"Content-Type":"application/json","x-goog-api-key":key},
      body:JSON.stringify({
        contents:[{parts:[
          {inline_data:{mime_type:m[1],data:m[2]}},
          {text:instruction}
        ]}],
        generationConfig:{responseModalities:["IMAGE"]}
      })
    });

    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({error:data?.error?.message || "Gemini image editing failed."});

    const parts = data?.candidates?.[0]?.content?.parts || [];
    const imagePart = parts.find(p => p.inlineData?.data || p.inline_data?.data);
    const b64 = imagePart?.inlineData?.data || imagePart?.inline_data?.data;
    const mime = imagePart?.inlineData?.mimeType || imagePart?.inline_data?.mime_type || "image/png";
    if (!b64) throw new Error("The image model did not return an edited image.");

    return res.status(200).json({image:`data:${mime};base64,${b64}`});
  } catch (e) {
    return res.status(500).json({error:e.message || "Image editing failed."});
  }
}