export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({error:"Method not allowed"});
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(500).json({error:"GEMINI_API_KEY is not configured in Vercel."});

  try {
    const {images} = req.body || {};
    if (!Array.isArray(images) || !images.length || images.length > 3)
      return res.status(400).json({error:"Send 1–3 images."});

    const parts = [{
      text: `You are GM Manager, a personal Instagram content strategist.
Analyze the supplied 1–3 photos and choose the best one for an Instagram post.
Do not infer sensitive traits. Focus only on visible photographic qualities.
Return ONLY valid JSON with these keys:
bestIndex (zero-based integer), score (0-100 integer), why, aesthetic, pose, composition, editing, music, postingTime, caption.
Keep the user's requested style: natural, premium, simple, clean, professional, human-looking, not over-edited.
For pose, recommend a natural pose; do not suggest changing face identity or body proportions.
For postingTime, say it is a starter suggestion unless real audience analytics are available.
Caption should be short and natural.` 
    }];

    for (const dataUrl of images) {
      const m = String(dataUrl).match(/^data:(image\/[^;]+);base64,(.+)$/);
      if (!m) continue;
      parts.push({inline_data:{mime_type:m[1],data:m[2]}});
    }

    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent", {
      method:"POST",
      headers:{"Content-Type":"application/json","x-goog-api-key":key},
      body:JSON.stringify({
        contents:[{parts}],
        generationConfig:{responseMimeType:"application/json"}
      })
    });

    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({error:data?.error?.message || "Gemini analysis failed."});

    const text = data?.candidates?.[0]?.content?.parts?.find(p=>p.text)?.text;
    if (!text) throw new Error("No analysis returned.");
    return res.status(200).json({result:JSON.parse(text)});
  } catch (e) {
    return res.status(500).json({error:e.message || "Analysis failed."});
  }
}